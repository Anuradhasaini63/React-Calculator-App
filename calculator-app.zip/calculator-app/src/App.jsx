import { useState } from 'react'
import './output.css'
import './App.css'
import Calculator from './Calculator'

function App() {

  return (
    <div className='text-center bg-black p-2 mx-auto'>
     <h1 className='text-white pb-2 text-lg font-bold'>Calculator App</h1>
     <Calculator/>
    </div>
  )
}

export default App
