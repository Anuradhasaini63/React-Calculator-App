import React, { useState } from 'react'
import './calculator.css'

const Calculator = () => {

    const [input, setInput] = useState('')

    const handleClick = (value) =>{
        setInput((prev) => prev + value);
    }

    const clearInput=()=>{
        setInput('');
    }

    const CalculateResult = () =>{
        try{
        setInput(eval(input).toString());
        }catch{
            setInput("There is an error");
        }
    }

  return (
    <div className='bg-slate-300 w-[215px] p-2 rounded-sm'>
        <div className='border-2 bg-white'>
            {input || 0}
        </div>
        <div className='all-btn'>
            {['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '.', '0', '=', '+'].map((btn)=>(
                <button key={btn} onClick={()=> (btn=== '=' ? CalculateResult(): handleClick(btn))}>{btn}</button>
            ))}
        </div>
        <button className='bg-red-500 text-white px-2 py-1 mt-5' onClick={clearInput}>Clear</button>
    </div>
  )
}

export default Calculator